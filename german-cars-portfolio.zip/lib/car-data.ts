export interface Brand {
  id: string
  name: string
  tagline: string
  logo: string
}

export interface Car {
  model: string
  price: string
  image: string
  description: string
  specs: { label: string; value: string }[]
}

export const brands: Brand[] = [
  {
    id: "bmw",
    name: "BMW",
    tagline: "The Ultimate Driving Machine",
    logo: "https://i.pinimg.com/originals/02/89/1c/02891cd77b2f84829eff448c351816bc.png",
  },
  {
    id: "mercedes",
    name: "Mercedes-Benz",
    tagline: "The Best or Nothing",
    logo: "https://i.pinimg.com/736x/79/96/20/79962051fbe8be17adf3701119d4b300.jpg",
  },
  {
    id: "audi",
    name: "Audi",
    tagline: "Vorsprung durch Technik",
    logo: "https://i.pinimg.com/736x/83/f6/32/83f632c19a6f430e632a116beec4b3bd.jpg",
  },
  {
    id: "vw",
    name: "Volkswagen",
    tagline: "Das Auto",
    logo: "https://i.pinimg.com/736x/f3/29/66/f3296621e671a99d9fccb0b124126cfa.jpg",
  },
]

export const carData: Record<string, Car[]> = {
  bmw: [
    {
      model: "BMW 3 Series",
      price: "$45,900",
      image: "https://i.pinimg.com/1200x/fd/97/ef/fd97efa64bb821194eee52fbc4535322.jpg",
      description:
        "Sleek sports sedan with aggressive styling and powerful performance. The iconic kidney grille and sharp lines embody pure driving pleasure.",
      specs: [
        { label: "Engine", value: "2.0L Turbo I4" },
        { label: "Horsepower", value: "255 HP" },
        { label: "0-60 mph", value: "5.6 seconds" },
        { label: "Transmission", value: "8-Speed Automatic" },
      ],
    },
    {
      model: "BMW X5",
      price: "$62,800",
      image: "https://i.pinimg.com/1200x/eb/d3/05/ebd305403a1fa46f56e6503e97328d97.jpg",
      description:
        "Luxury SUV that dominates the road with commanding presence. Spacious, powerful, and perfect for both city streets and mountain roads.",
      specs: [
        { label: "Engine", value: "3.0L Turbo I6" },
        { label: "Horsepower", value: "335 HP" },
        { label: "0-60 mph", value: "5.3 seconds" },
        { label: "Seating", value: "5-7 Passengers" },
      ],
    },
    {
      model: "BMW M4",
      price: "$74,700",
      image: "https://i.pinimg.com/1200x/45/d2/87/45d287c4a8c25f8d3e68380048825c02.jpg",
      description:
        "Race-bred performance coupe with stunning blue finish. Twin-turbo power meets precision handling for pure adrenaline on every drive.",
      specs: [
        { label: "Engine", value: "3.0L Twin-Turbo I6" },
        { label: "Horsepower", value: "503 HP" },
        { label: "0-60 mph", value: "3.8 seconds" },
        { label: "Top Speed", value: "180 mph" },
      ],
    },
    {
      model: "BMW iX",
      price: "$87,250",
      image: "https://i.pinimg.com/736x/5f/a7/d2/5fa7d24aa4aa1dc29f698f4d72727c0c.jpg",
      description:
        "Futuristic all-electric SUV with bold design language. Silent power delivery with impressive range for the electric revolution.",
      specs: [
        { label: "Motor", value: "Dual Electric" },
        { label: "Horsepower", value: "516 HP" },
        { label: "0-60 mph", value: "4.6 seconds" },
        { label: "Range", value: "324 miles" },
      ],
    },
  ],
  mercedes: [
    {
      model: "C-Class",
      price: "$44,600",
      image: "https://i.pinimg.com/736x/95/2e/8a/952e8aa0f4f200aa44b1e89ca3698904.jpg",
      description:
        "Elegant luxury sedan with timeless Mercedes sophistication. Premium interior craftsmanship meets advanced driver assistance technology.",
      specs: [
        { label: "Engine", value: "2.0L Turbo I4" },
        { label: "Horsepower", value: "255 HP" },
        { label: "0-60 mph", value: "5.9 seconds" },
        { label: "Transmission", value: "9-Speed Automatic" },
      ],
    },
    {
      model: "GLE",
      price: "$59,500",
      image: "https://i.pinimg.com/1200x/f9/a7/c5/f9a7c5d06b05e792558f7a0382788e3b.jpg",
      description:
        "Bold luxury SUV with muscular stance and commanding road presence. Spacious seven-seater comfort meets Mercedes engineering excellence.",
      specs: [
        { label: "Engine", value: "2.0L Turbo I4" },
        { label: "Horsepower", value: "255 HP" },
        { label: "0-60 mph", value: "6.9 seconds" },
        { label: "Seating", value: "5-7 Passengers" },
      ],
    },
    {
      model: "AMG GT",
      price: "$139,900",
      image: "https://i.pinimg.com/1200x/00/88/6e/00886eb5a88a86c74ea4de502e062f6a.jpg",
      description:
        "Breathtaking sports car with striking yellow performance. Handcrafted AMG V8 engine delivers supercar thrills and head-turning presence.",
      specs: [
        { label: "Engine", value: "4.0L Twin-Turbo V8" },
        { label: "Horsepower", value: "523 HP" },
        { label: "0-60 mph", value: "3.5 seconds" },
        { label: "Top Speed", value: "193 mph" },
      ],
    },
    {
      model: "EQS",
      price: "$105,550",
      image: "https://i.pinimg.com/1200x/d5/da/2e/d5da2ea99c5e80d716988c103882afe7.jpg",
      description:
        "Revolutionary electric luxury sedan with stunning aerodynamic design. Ultra-modern interior with massive Hyperscreen and whisper-quiet performance.",
      specs: [
        { label: "Motor", value: "Dual Electric" },
        { label: "Horsepower", value: "329 HP" },
        { label: "0-60 mph", value: "5.5 seconds" },
        { label: "Range", value: "350 miles" },
      ],
    },
  ],
  audi: [
    {
      model: "Audi A4",
      price: "$40,500",
      image: "https://i.pinimg.com/736x/76/5e/67/765e67d59b5fd7ac0bcf9ba24c76262c.jpg",
      description: "Progressive design with quattro all-wheel drive and intelligent technology.",
      specs: [
        { label: "Engine", value: "2.0L Turbo I4" },
        { label: "Horsepower", value: "201 HP" },
        { label: "0-60 mph", value: "5.6 seconds" },
        { label: "Drive", value: "Quattro AWD" },
      ],
    },
    {
      model: "Audi Q7",
      price: "$57,800",
      image: "https://i.pinimg.com/736x/44/88/35/44883557955b7dfc68113071cf3791e8.jpg",
      description: "Premium SUV offering seven seats, versatility, and refined comfort.",
      specs: [
        { label: "Engine", value: "2.0L Turbo I4" },
        { label: "Horsepower", value: "248 HP" },
        { label: "0-60 mph", value: "6.3 seconds" },
        { label: "Seating", value: "7 Passengers" },
      ],
    },
    {
      model: "Audi RS6 Avant",
      price: "$116,500",
      image: "https://i.pinimg.com/1200x/c8/48/29/c84829a861386f9eab6cce28cadd2271.jpg",
      description: "High-performance wagon combining practicality with supercar-level power.",
      specs: [
        { label: "Engine", value: "4.0L Twin-Turbo V8" },
        { label: "Horsepower", value: "591 HP" },
        { label: "0-60 mph", value: "3.5 seconds" },
        { label: "Top Speed", value: "190 mph" },
      ],
    },
    {
      model: "Audi e-tron GT",
      price: "$106,500",
      image: "https://i.pinimg.com/736x/88/3d/f7/883df7f3af389e61f2e67579d1a02f1d.jpg",
      description: "Electric gran turismo with stunning design and exhilarating performance.",
      specs: [
        { label: "Motor", value: "Dual Electric" },
        { label: "Horsepower", value: "522 HP" },
        { label: "0-60 mph", value: "3.9 seconds" },
        { label: "Range", value: "238 miles" },
      ],
    },
  ],
  vw: [
    {
      model: "Golf",
      price: "$29,545",
      image: "https://i.pinimg.com/1200x/17/97/7e/17977e217a573b70be17611e4f256929.jpg",
      description: "The iconic hatchback setting standards for quality, practicality, and driving enjoyment.",
      specs: [
        { label: "Engine", value: "1.4L Turbo I4" },
        { label: "Horsepower", value: "147 HP" },
        { label: "0-60 mph", value: "7.9 seconds" },
        { label: "MPG", value: "30 city / 41 hwy" },
      ],
    },
    {
      model: "Tiguan",
      price: "$28,545",
      image: "https://i.pinimg.com/1200x/59/44/5b/59445b29ca4ee7c6e9570ee199bd71ed.jpg",
      description: "Versatile SUV with modern design, spacious interior, and advanced safety features.",
      specs: [
        { label: "Engine", value: "2.0L Turbo I4" },
        { label: "Horsepower", value: "184 HP" },
        { label: "0-60 mph", value: "8.4 seconds" },
        { label: "Seating", value: "5-7 Passengers" },
      ],
    },
    {
      model: "Golf GTI",
      price: "$31,370",
      image: "https://i.pinimg.com/1200x/17/97/7e/17977e217a573b70be17611e4f256929.jpg",
      description: "The original hot hatch delivering thrilling performance and everyday usability.",
      specs: [
        { label: "Engine", value: "2.0L Turbo I4" },
        { label: "Horsepower", value: "228 HP" },
        { label: "0-60 mph", value: "6.0 seconds" },
        { label: "Transmission", value: "6-Speed Manual" },
      ],
    },
    {
      model: "ID.4",
      price: "$43,995",
      image: "https://i.pinimg.com/736x/a5/1d/c9/a51dc95fd8d5cc77fe359be015f539d4.jpg",
      description: "All-electric SUV combining sustainable mobility with spacious comfort.",
      specs: [
        { label: "Motor", value: "Single Electric" },
        { label: "Horsepower", value: "201 HP" },
        { label: "0-60 mph", value: "7.6 seconds" },
        { label: "Range", value: "275 miles" },
      ],
    },
  ],
}
