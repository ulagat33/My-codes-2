"use client"

import { useState } from "react"
import Header from "@/components/header"
import BrandGrid from "@/components/brand-grid"
import BrandShowcase from "@/components/brand-showcase"
import ContactFooter from "@/components/contact-footer"
import { brands, carData } from "@/lib/car-data"

export default function Home() {
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null)
  const [showContact, setShowContact] = useState(false)

  const handleBrandSelect = (brandId: string) => {
    setSelectedBrand(brandId)
    setShowContact(false)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleCloseBrand = () => {
    setSelectedBrand(null)
    setShowContact(false)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleContactClick = (carModel: string) => {
    setShowContact(true)
    setTimeout(() => {
      document.getElementById("contactSection")?.scrollIntoView({ behavior: "smooth" })
    }, 100)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-neutral-900 to-neutral-800 text-white">
      <div className="max-w-7xl mx-auto px-5 py-5">
        <Header />

        {!selectedBrand ? (
          <BrandGrid brands={brands} onBrandSelect={handleBrandSelect} />
        ) : (
          <BrandShowcase
            brand={brands.find((b) => b.id === selectedBrand)!}
            cars={carData[selectedBrand]}
            onClose={handleCloseBrand}
            onContactClick={handleContactClick}
          />
        )}

        {showContact && <ContactFooter />}
      </div>
    </div>
  )
}
