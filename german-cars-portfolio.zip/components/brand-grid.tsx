"use client"

import Image from "next/image"
import type { Brand } from "@/lib/car-data"

interface BrandGridProps {
  brands: Brand[]
  onBrandSelect: (brandId: string) => void
}

export default function BrandGrid({ brands, onBrandSelect }: BrandGridProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
      {brands.map((brand) => (
        <div
          key={brand.id}
          onClick={() => onBrandSelect(brand.id)}
          className="bg-white/5 border-2 border-white/10 rounded-2xl p-10 text-center cursor-pointer transition-all duration-300 hover:-translate-y-3 hover:border-white/30 hover:bg-white/10 hover:shadow-2xl"
        >
          <div className="w-36 h-36 mx-auto mb-5 rounded-full overflow-hidden border-3 border-white/20 transition-transform duration-300 hover:rotate-360">
            <Image
              src={brand.logo || "/placeholder.svg"}
              alt={`${brand.name} Logo`}
              width={150}
              height={150}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="text-3xl font-bold mb-2">{brand.name}</div>
          <div className="text-neutral-400 text-sm">{brand.tagline}</div>
        </div>
      ))}
    </div>
  )
}
