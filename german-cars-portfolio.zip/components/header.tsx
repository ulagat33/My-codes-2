export default function Header() {
  return (
    <header className="text-center py-10 px-5 bg-black/30 mb-10 rounded-xl">
      <h1 className="text-5xl md:text-6xl font-bold mb-3 bg-gradient-to-r from-white to-neutral-400 bg-clip-text text-transparent">
        German Automotive Excellence
      </h1>
      <p className="text-xl text-neutral-400">Explore the World&apos;s Finest Car Brands</p>
    </header>
  )
}
