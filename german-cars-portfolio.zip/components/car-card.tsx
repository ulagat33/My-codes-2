"use client"

import Image from "next/image"
import type { Car } from "@/lib/car-data"

interface CarCardProps {
  car: Car
  onContactClick: (carModel: string) => void
}

export default function CarCard({ car, onContactClick }: CarCardProps) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-xl overflow-hidden transition-all duration-300 hover:-translate-y-2 hover:border-white/30 hover:shadow-2xl">
      <div className="w-full h-64 overflow-hidden relative">
        <Image
          src={car.image || "/placeholder.svg"}
          alt={car.model}
          width={400}
          height={250}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
        />
        <div className="absolute top-4 right-4 bg-black/80 px-5 py-2 rounded-full text-xl font-bold text-green-500">
          {car.price}
        </div>
      </div>

      <div className="p-6">
        <div className="text-2xl font-bold mb-3">{car.model}</div>
        <div className="text-neutral-400 text-sm leading-relaxed mb-5">{car.description}</div>

        <div className="bg-white/5 p-4 rounded-lg mb-4">
          {car.specs.map((spec, index) => (
            <div
              key={index}
              className={`flex justify-between py-2 ${
                index !== car.specs.length - 1 ? "border-b border-white/10" : ""
              }`}
            >
              <span className="text-neutral-500 text-sm">{spec.label}</span>
              <span className="font-bold text-white">{spec.value}</span>
            </div>
          ))}
        </div>

        <button
          onClick={() => onContactClick(car.model)}
          className="w-full bg-gradient-to-r from-purple-600 to-purple-800 border-none text-white py-3 rounded-lg cursor-pointer text-base font-bold transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-purple-600/40"
        >
          Contact for Details
        </button>
      </div>
    </div>
  )
}
