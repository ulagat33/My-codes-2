export default function ContactFooter() {
  return (
    <footer id="contactSection" className="bg-black/30 p-10 mt-16 rounded-xl text-center">
      <h2 className="text-3xl font-bold mb-5">Get in Touch</h2>

      <div className="flex justify-center gap-10 flex-wrap mb-5">
        <div className="flex items-center gap-3">
          <span className="text-2xl">📧</span>
          <span>ulagatuni@gmail.com</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-2xl">📱</span>
          <span>+7 707 222 1523</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-2xl">📍</span>
          <span>Almaty, Kazakhstan</span>
        </div>
      </div>

      <div className="flex justify-center gap-5 mt-5">
        {[
          { icon: "📷", title: "Instagram" },
          { icon: "📘", title: "Facebook" },
          { icon: "🐦", title: "Twitter" },
          { icon: "💼", title: "LinkedIn" },
        ].map((social) => (
          <a
            key={social.title}
            href="#"
            title={social.title}
            className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center text-2xl transition-all duration-300 hover:bg-white/20 hover:-translate-y-2"
          >
            {social.icon}
          </a>
        ))}
      </div>

      <p className="mt-8 text-neutral-600">© 2025 German Automotive Excellence. All rights reserved.</p>
    </footer>
  )
}
