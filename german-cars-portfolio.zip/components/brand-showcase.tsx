"use client"

import type { Brand, Car } from "@/lib/car-data"
import CarCard from "./car-card"

interface BrandShowcaseProps {
  brand: Brand
  cars: Car[]
  onClose: () => void
  onContactClick: (carModel: string) => void
}

export default function BrandShowcase({ brand, cars, onClose, onContactClick }: BrandShowcaseProps) {
  return (
    <div className="bg-black/50 p-10 rounded-2xl animate-fade-in">
      <div className="flex justify-between items-center mb-8 pb-5 border-b-2 border-white/20">
        <h2 className="text-4xl md:text-5xl font-bold">{brand.name} Models</h2>
        <button
          onClick={onClose}
          className="bg-white/10 border-2 border-white/30 text-white px-6 py-3 rounded-lg cursor-pointer text-base transition-all duration-300 hover:bg-white/20 hover:scale-105"
        >
          Back to Brands
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {cars.map((car, index) => (
          <CarCard key={index} car={car} onContactClick={onContactClick} />
        ))}
      </div>
    </div>
  )
}
